// SPDX-License-Identifier: BSD-3-Clause
#include <getopt.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>

#include "qdl.h"

#ifdef _WIN32
const char *__progname = "ramdump";
#endif

bool qdl_debug;

static void print_usage(FILE *out)
{
	extern const char *__progname;

	fprintf(out,
		"%s [--debug] [-o <ramdump-path>] [segment-filter]\n\n"
		" -d, --debug\t\tEnable debug output\n"
		" -v, --version\t\tPrint version\n"
		" -o, --output=PATH\tDirectory to write ramdump segments into (default: .)\n"
		" -S, --serial=T\t\tSelect target by serial number T (e.g. <0AA94EFD>)\n"
		" -h, --help\t\tPrint this usage info\n"
		" [segment-filter]\tOptional comma-separated list of segment names to dump\n",
		__progname);
}

int main(int argc, char **argv)
{
	struct qdl_device *qdl;

	qdl = qdl_init(QDL_DEVICE_AUTO);
	if (!qdl)
		return 1;

	char *ramdump_path = ".";
	char *filter = NULL;
	char *serial = NULL;
	int ret = 0;
	int opt;

	static struct option options[] = {
		{"debug", no_argument, 0, 'd'},
		{"version", no_argument, 0, 'v'},
		{"output", required_argument, 0, 'o'},
		{"serial", required_argument, 0, 'S'},
		{"help", no_argument, 0, 'h'},
		{0, 0, 0, 0}
	};

	while ((opt = getopt_long(argc, argv, "dvo:S:h", options, NULL)) != -1) {
		switch (opt) {
		case 'd':
			qdl_debug = true;
			break;
		case 'v':
			print_version();
			ret = 0;
			goto out_cleanup;
		case 'o':
			ramdump_path = optarg;
			break;
		case 'S':
			serial = optarg;
			break;
		case 'h':
			print_usage(stdout);
			return 0;
		default:
			print_usage(stderr);
			return 1;
		}
	}

	if (optind < argc)
		filter = argv[optind++];

	if (optind != argc) {
		print_usage(stderr);
		return 1;
	}

	ux_init();

	if (qdl_debug)
		print_version();

	ret = qdl_open(qdl, serial);
	if (ret) {
		ret = 1;
		goto out_cleanup;
	}

	ret = sahara_run(qdl, NULL, ramdump_path, filter);
	if (ret < 0) {
		ret = 1;
		goto out_cleanup;
	}

out_cleanup:
	qdl_close(qdl);
	qdl_deinit(qdl);

	return ret;
}
