// SPDX-License-Identifier: BSD-3-Clause
#include <sys/types.h>
#include <errno.h>
#include <fcntl.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <libusb.h>
#ifndef _WIN32
#include <sys/stat.h>
#endif
#include "oscompat.h"

#include "qdl.h"

#define DEFAULT_OUT_CHUNK_SIZE (1024 * 1024)

/*
 * Software-replug recovery (see usb_reset): how long to let a port-reset device
 * re-enumerate and re-emit its one-shot Sahara HELLO, and how many re-open
 * passes to attempt before giving up.
 */
#define USB_RESET_SETTLE_US	2000000
#define USB_REOPEN_RETRIES	10

struct qdl_device_usb {
	struct qdl_device base;
	struct libusb_device_handle *usb_handle;
	char serial[64];		/* device serial, to re-open by after a port reset */

	int in_ep;
	int out_ep;

	size_t in_maxpktsize;
	size_t out_maxpktsize;
	size_t out_chunk_size;

	/* 仅在 usb_reset(wedge 恢复 replug)时置位，令 re-open 复位 data-toggle；
	 * 初始 open 保持 false，避免无谓 SET_INTERFACE 扰动正常握手的设备(如 SM8650)。 */
	bool reset_toggle;
};

/*
 * libusb commit f0cce43f882d ("core: Fix definition and use of enum
 * libusb_transfer_type") split transfer type and endpoint transfer types.
 * Provide an alias in order to make the code compile with the old (non-split)
 * definition.
 */
#ifndef LIBUSB_ENDPOINT_TRANSFER_TYPE_BULK
#define LIBUSB_ENDPOINT_TRANSFER_TYPE_BULK LIBUSB_TRANSFER_TYPE_BULK
#endif

static bool usb_read_serial(struct libusb_device_handle *handle,
			    const struct libusb_device_descriptor *desc,
			    char *out, size_t out_len)
{
	char buf[128];
	char *p;
	int ret;

	ret = libusb_get_string_descriptor_ascii(handle, desc->iProduct, (unsigned char *)buf, sizeof(buf));
	if (ret < 0) {
		warnx("failed to read iProduct descriptor: %s", libusb_strerror(ret));
		return false;
	}

	p = strstr(buf, "_SN:");
	if (!p)
		return false;

	p += strlen("_SN:");
	p[strcspn(p, " _")] = '\0';

	snprintf(out, out_len, "%s", p);
	return true;
}

static bool usb_match_usb_serial(struct libusb_device_handle *handle, const char *serial,
				 const struct libusb_device_descriptor *desc)
{
	char buf[64];

	/* If no serial is requested, consider everything a match */
	if (!serial)
		return true;

	if (!usb_read_serial(handle, desc, buf, sizeof(buf)))
		return false;

	return strcmp(buf, serial) == 0;
}

static int usb_try_open(libusb_device *dev, struct qdl_device_usb *qdl, const char *serial)
{
	const struct libusb_endpoint_descriptor *endpoint;
	const struct libusb_interface_descriptor *ifc;
	struct libusb_config_descriptor *config;
	struct libusb_device_descriptor desc;
	struct libusb_device_handle *handle;
	size_t out_size;
	size_t in_size;
	uint8_t type;
	int ret;
	int out;
	int in;
	int k;
	int l;

	ret = libusb_get_device_descriptor(dev, &desc);
	if (ret < 0) {
		warnx("failed to get USB device descriptor");
		return -1;
	}

	/* Consider only devices with vid 0x05c6 and known product id */
	if (desc.idVendor != 0x05c6)
		return 0;
	if (desc.idProduct != 0x9008 && desc.idProduct != 0x900e && desc.idProduct != 0x901d)
		return 0;

	/* Match by USB bus path (Android env var QDL_USB_PATH) */
	bool path_matched = false;
	if (serial && strstr(serial, "/dev/bus/usb/") == serial) {
		uint8_t bus = libusb_get_bus_number(dev);
		uint8_t addr = libusb_get_device_address(dev);
		char dev_path[64];
		snprintf(dev_path, sizeof(dev_path), "/dev/bus/usb/%03d/%03d", bus, addr);
		if (strcmp(serial, dev_path) != 0)
			return 0;
		path_matched = true;
	}

	ret = libusb_get_active_config_descriptor(dev, &config);
	if (ret < 0) {
		warnx("failed to acquire USB device's active config descriptor");
		return -1;
	}

	for (k = 0; k < config->bNumInterfaces; k++) {
		ifc = config->interface[k].altsetting;

		in = -1;
		out = -1;
		in_size = 0;
		out_size = 0;

		for (l = 0; l < ifc->bNumEndpoints; l++) {
			endpoint = &ifc->endpoint[l];

			type = endpoint->bmAttributes & LIBUSB_TRANSFER_TYPE_MASK;
			if (type != LIBUSB_ENDPOINT_TRANSFER_TYPE_BULK)
				continue;

			if (endpoint->bEndpointAddress & LIBUSB_ENDPOINT_IN) {
				in = endpoint->bEndpointAddress;
				in_size = endpoint->wMaxPacketSize;
			} else {
				out = endpoint->bEndpointAddress;
				out_size = endpoint->wMaxPacketSize;
			}
		}

		if (ifc->bInterfaceClass != 0xff)
			continue;

		if (ifc->bInterfaceSubClass != 0xff)
			continue;

		/* bInterfaceProtocol of 0xff, 0x10 and 0x11 has been seen */
		if (ifc->bInterfaceProtocol != 0xff &&
		    ifc->bInterfaceProtocol != 16 &&
		    ifc->bInterfaceProtocol != 17)
			continue;

		/*
		 * 仅接受同时具备 bulk IN/OUT 端点的接口。缺一端点时 in_size/out_size 仍为 0，
		 * 后续 out_chunk_size % out_size、actual % in_maxpktsize 等取模会除零(SIGFPE)；
		 * 或以 in_ep/out_ep=-1 被接受致所有传输静默失败。对齐 qdlrs 的 num_endpoints>=2 守卫。
		 */
		if (in == -1 || out == -1 || in_size == 0 || out_size == 0)
			continue;

		ret = libusb_open(dev, &handle);
		if (ret < 0) {
			warnx("unable to open USB device");
			continue;
		}

		/* Skip serial check if already matched by bus path */
		if (!path_matched && !usb_match_usb_serial(handle, serial, &desc)) {
			libusb_close(handle);
			continue;
		}

		/*
		 * 复现内核 usb-serial open 的端点初始化——libusb 默认一步都不做。
		 * SET_CONFIGURATION 确保配置已选中（仅在未选中时发，避免无谓重置）。
		 */
		{
			int active_cfg = -1;

			libusb_get_configuration(handle, &active_cfg);
			if (config->bConfigurationValue &&
			    active_cfg != config->bConfigurationValue)
				libusb_set_configuration(handle, config->bConfigurationValue);
		}

		libusb_detach_kernel_driver(handle, ifc->bInterfaceNumber);

		ret = libusb_claim_interface(handle, ifc->bInterfaceNumber);
		if (ret < 0) {
			warnx("failed to claim USB interface");
			libusb_close(handle);
			continue;
		}

		/*
		 * SET_INTERFACE 复位端点 data toggle(USB2.0 §9.4.10)：仅在 wedge 恢复的
		 * replug(usb_reset 置 reset_toggle)时执行。小米 SDM845 的 PBL 被前序会话
		 * wedge 后 toggle 失步、bulk 双向静默，靠它归零救活；但对刚冷枚举、握手正常
		 * 的设备(如 SM8650/8Gen3)，初始 open 就无条件下发反而扰动 OUT 端点，使紧随
		 * HELLO 的 HELLO_RESPONSE 写挂死、设备永不发 READ64。故改为按需触发。
		 */
		if (qdl->reset_toggle) {
			/* best-effort：单 alt 接口可能 STALL，忽略返回值即可。 */
			libusb_set_interface_alt_setting(handle, ifc->bInterfaceNumber,
							 ifc->bAlternateSetting);

			/* clear_halt 作补充：端点确实 halt 时才有意义，对正常设备是 no-op。 */
			libusb_clear_halt(handle, in);
			libusb_clear_halt(handle, out);
		}

		qdl->usb_handle = handle;
		qdl->in_ep = in;
		qdl->out_ep = out;
		qdl->in_maxpktsize = in_size;
		qdl->out_maxpktsize = out_size;

		if (qdl->out_chunk_size && qdl->out_chunk_size % out_size) {
			ux_err("WARNING: requested out-chunk-size must be multiple of the device's wMaxPacketSize %ld, using %ld\n",
			       out_size, out_size);
			qdl->out_chunk_size = out_size;
		} else if (!qdl->out_chunk_size) {
			qdl->out_chunk_size = DEFAULT_OUT_CHUNK_SIZE;
		}

		ux_debug("USB: using out-chunk-size of %ld\n", qdl->out_chunk_size);

		break;
	}

	libusb_free_config_descriptor(config);

	return !!qdl->usb_handle;
}

static bool usb_is_edl_pid(uint16_t pid)
{
	return pid == 0x9008 || pid == 0x900e || pid == 0x901d;
}

/*
 * try_usb_open() - one libusb scan-and-open pass.
 *
 * Used as the single iteration unit by both usb_open() (the --backend usb
 * wait loop) and auto_open() (the unified Windows libusb+QUD wait loop).
 *
 * On success, populates @qdl and emits the "Flashing/Collecting device"
 * UX line; the caller need not log anything.
 *
 * Returns:
 *    0          - device opened, @qdl is ready
 *   -ENODEV     - no EDL device currently visible
 *   -EBUSY      - EDL device(s) visible but none could be opened
 *                 (typically: another driver, usually the Qualcomm
 *                  QDLoader 9008 driver behind the QUD backend, has
 *                  claimed the USB interface)
 *   -EIO        - libusb itself failed (init/get_device_list)
 *
 * @visible_out, when non-NULL, receives the number of EDL devices that
 * libusb saw on this pass, so callers that loop can print transition
 * diagnostics without re-enumerating.
 *
 * Does its own libusb_init()/libusb_exit() so the next call sees a
 * fresh enumeration (libusb's udev-less backends otherwise cache the
 * list, which would mask newly-attached devices in containerised setups).
 */
int try_usb_open(struct qdl_device *qdl, const char *serial, int *visible_out)
{
	struct qdl_device_usb *qdl_usb = container_of(qdl, struct qdl_device_usb, base);
	struct libusb_device_descriptor desc;
	struct libusb_device **devs;
	struct libusb_device *dev;
	char matched_serial[64];
	uint16_t matched_pid = 0;
	bool found = false;
	int visible = 0;
	ssize_t n;
	int ret;
	int i;

	if (visible_out)
		*visible_out = 0;

	ret = libusb_init(NULL);
	if (ret < 0) {
		ux_err("failed to initialize libusb: %s\n", libusb_strerror(ret));
		return -EIO;
	}

	n = libusb_get_device_list(NULL, &devs);
	if (n < 0) {
		ux_err("failed to list USB devices: %s\n", libusb_strerror(n));
		libusb_exit(NULL);
		return -EIO;
	}

	for (i = 0; devs[i]; i++) {
		dev = devs[i];

		if (libusb_get_device_descriptor(dev, &desc) < 0)
			continue;
		if (desc.idVendor != 0x05c6 || !usb_is_edl_pid(desc.idProduct))
			continue;

		visible++;

		ret = usb_try_open(dev, qdl_usb, serial);
		if (ret == 1) {
			found = true;
			matched_pid = desc.idProduct;
			if (!usb_read_serial(qdl_usb->usb_handle, &desc,
					     matched_serial, sizeof(matched_serial)))
				matched_serial[0] = '\0';
			break;
		}
	}

	if (visible_out)
		*visible_out = visible;

	if (found) {
		const char *action = matched_pid == 0x900e ? "Collecting crash dump from" : "Flashing";

		/* Remember the real serial so usb_reset can re-open this device by
		 * serial after a port reset re-enumerates it at a new bus address.
		 * Also expose it on the base device so transport-agnostic code (the
		 * OnePlus token handshake) can read the SoC serial without reaching
		 * into the USB backend. */
		snprintf(qdl_usb->serial, sizeof(qdl_usb->serial), "%s", matched_serial);
		snprintf(qdl->serial, sizeof(qdl->serial), "%s", matched_serial);

		libusb_free_device_list(devs, 1);
		if (matched_serial[0])
			ux_info("%s device (PID 0x%04x, serial: %s)\n",
				action, matched_pid, matched_serial);
		else
			ux_info("%s device (PID 0x%04x)\n", action, matched_pid);
		return 0;
	}

	libusb_free_device_list(devs, 1);
	libusb_exit(NULL);

	return visible == 0 ? -ENODEV : -EBUSY;
}

static int usb_open(struct qdl_device *qdl, const char *serial)
{
	int visible_prev = -1;
	int visible;
	int ret;

	for (;;) {
		ret = try_usb_open(qdl, serial, &visible);
		if (ret == 0)
			return 0;
		if (ret == -EIO)
			return -1;

		if (visible != visible_prev) {
			if (visible == 0) {
				ux_info("Waiting for EDL device\n");
			} else if (serial) {
				ux_info("%d EDL device(s) visible, none match serial \"%s\"\n",
					visible, serial);
			} else {
				ux_info("%d EDL device(s) visible, none could be opened\n",
					visible);
			}
			visible_prev = visible;
		}

		usleep(250000);
	}
}

struct qdl_device_desc *usb_list(unsigned int *devices_found)
{
	struct libusb_device_descriptor desc;
	struct libusb_device_handle *handle;
	struct qdl_device_desc *result;
	struct libusb_device **devices;
	struct libusb_device *dev;
	unsigned long serial_len;
	unsigned char buf[128];
	ssize_t device_count;
	unsigned int count = 0;
	char *serial;
	int ret;
	int i;

	ret = libusb_init(NULL);
	if (ret < 0) {
		ux_err("failed to initialize libusb: %s\n", libusb_strerror(ret));
		return NULL;
	}

	device_count = libusb_get_device_list(NULL, &devices);
	if (device_count < 0) {
		ux_err("failed to list USB devices: %s\n", libusb_strerror(device_count));
		libusb_exit(NULL);
		return NULL;
	}
	if (device_count == 0)
		return NULL;

	result = calloc(device_count, sizeof(struct qdl_device_desc));
	if (!result) {
		ux_err("failed to allocate devices array\n");
		libusb_free_device_list(devices, 1);
		libusb_exit(NULL);
		return NULL;
	}

	for (i = 0; i < device_count; i++) {
		dev = devices[i];

		ret = libusb_get_device_descriptor(dev, &desc);
		if (ret < 0) {
			warnx("failed to get USB device descriptor");
			continue;
		}

		if (desc.idVendor != 0x05c6)
			continue;
		if (desc.idProduct != 0x9008 && desc.idProduct != 0x900e && desc.idProduct != 0x901d)
			continue;

		ret = libusb_open(dev, &handle);
		if (ret < 0)
			continue;

		ret = libusb_get_string_descriptor_ascii(handle, desc.iProduct, buf, sizeof(buf) - 1);
		if (ret < 0) {
			warnx("failed to read iProduct descriptor: %s", libusb_strerror(ret));
			libusb_close(handle);
			continue;
		}
		buf[ret] = '\0';

		serial = strstr((char *)buf, "_SN:");
		if (!serial) {
			memcpy(result[count].serial, "(none)", sizeof("(none)"));
		} else {
			serial += strlen("_SN:");
			serial_len = strcspn(serial, " _");
			if (serial_len + 1 > sizeof(result[count].serial)) {
				ux_err("ignoring device with unexpectedly long serial number\n");
				libusb_close(handle);
				continue;
			}

			memcpy(result[count].serial, serial, serial_len);
			result[count].serial[serial_len] = '\0';
		}

		result[count].vid = desc.idVendor;
		result[count].pid = desc.idProduct;
		libusb_close(handle);
		count++;
	}

	libusb_free_device_list(devices, 1);
	*devices_found = count;

	return result;
}

static void usb_close(struct qdl_device *qdl)
{
	struct qdl_device_usb *qdl_usb = container_of(qdl, struct qdl_device_usb, base);

	/* usb_reset() leaves a NULL handle when it can't re-open the device. */
	if (qdl_usb->usb_handle)
		libusb_close(qdl_usb->usb_handle);
	libusb_exit(NULL);
}

static int usb_read(struct qdl_device *qdl, void *buf, size_t len, unsigned int timeout)
{
	struct qdl_device_usb *qdl_usb = container_of(qdl, struct qdl_device_usb, base);
	int actual;
	int ret;

	ret = libusb_bulk_transfer(qdl_usb->usb_handle, qdl_usb->in_ep, buf, len, &actual, timeout);
	if (ret != 0 && ret != LIBUSB_ERROR_TIMEOUT)
		return -EIO;

	if (ret == LIBUSB_ERROR_TIMEOUT && actual == 0)
		return -ETIMEDOUT;

	/* If what we read equals the endpoint's Max Packet Size, consume the ZLP explicitly */
	if (len == (size_t)actual && !(actual % qdl_usb->in_maxpktsize)) {
		ret = libusb_bulk_transfer(qdl_usb->usb_handle, qdl_usb->in_ep,
					   NULL, 0, NULL, timeout);
		if (ret)
			warnx("Unable to read ZLP: %s", libusb_strerror(ret));
	}

	return actual;
}

static int usb_write(struct qdl_device *qdl, const void *buf, size_t len, unsigned int timeout)
{
	unsigned char *data = (unsigned char *)buf;
	struct qdl_device_usb *qdl_usb = container_of(qdl, struct qdl_device_usb, base);
	unsigned int count = 0;
	size_t len_orig = len;
	int actual;
	int xfer;
	int ret;

	while (len > 0) {
		xfer = (len > qdl_usb->out_chunk_size) ? qdl_usb->out_chunk_size : len;

		ret = libusb_bulk_transfer(qdl_usb->usb_handle, qdl_usb->out_ep, data,
					   xfer, &actual, timeout);
		if (ret != 0 && ret != LIBUSB_ERROR_TIMEOUT) {
			/* Retry once before giving up */
			warnx("bulk write failed: %s, retrying", libusb_strerror(ret));
			ret = libusb_bulk_transfer(qdl_usb->usb_handle, qdl_usb->out_ep,
						   data, xfer, &actual, timeout);
			if (ret != 0 && ret != LIBUSB_ERROR_TIMEOUT) {
				warnx("bulk write retry failed: %s", libusb_strerror(ret));
				return -EIO;
			}
		}
		if (ret == LIBUSB_ERROR_TIMEOUT && actual == 0)
			return -ETIMEDOUT;

		count += actual;
		len -= actual;
		data += actual;
	}

	if (len_orig % qdl_usb->out_maxpktsize == 0) {
		ret = libusb_bulk_transfer(qdl_usb->usb_handle, qdl_usb->out_ep, NULL,
					   0, &actual, timeout);
		if (ret < 0)
			return -EIO;
	}

	return count;
}

static void usb_set_out_chunk_size(struct qdl_device *qdl, long size)
{
	struct qdl_device_usb *qdl_usb = container_of(qdl, struct qdl_device_usb, base);

	qdl_usb->out_chunk_size = size;
}

/*
 * Lightweight endpoint resync. Recovers a device whose bulk endpoints went
 * silent after a previous session — claim succeeds but transfers never reach
 * the firmware because the host/device bulk data toggle is out of sync (seen on
 * 小米 SDM845 in 9008; the tell-tale is bulk going quiet in both directions with
 * no error).
 *
 * We deliberately do NOT issue a USB bus reset (libusb_reset_device /
 * USBDEVFS_RESET): on Qualcomm PBLs that tends to deepen the lockup and rarely
 * restarts the on-die boot ROM. Instead we drop the handle and re-open — and the
 * re-open path issues SET_INTERFACE, which unconditionally re-zeroes the endpoint
 * toggle on both host and device (see usb_try_open), the cheap correct fix for
 * the wedge. Re-open is by serial (stable, unambiguous identity).
 *
 * Returns 0 with a fresh handle ready, or -ENODEV if the device is gone (caller
 * should ask the user to physically replug into 9008).
 */
static int usb_reset(struct qdl_device *qdl)
{
	struct qdl_device_usb *qdl_usb = container_of(qdl, struct qdl_device_usb, base);
	char serial[sizeof(qdl_usb->serial)];
	int tries;
	int ret;

	if (!qdl_usb->usb_handle)
		return -ENODEV;

	/*
	 * Re-open by serial; without one we'd fall back to matching "any 9008",
	 * which could grab the wrong target when several are attached.
	 */
	if (!qdl_usb->serial[0])
		return -ENODEV;
	snprintf(serial, sizeof(serial), "%s", qdl_usb->serial);

	/* 这是 wedge 恢复 replug：令随后的 re-open 复位 data-toggle(见 usb_try_open)。 */
	qdl_usb->reset_toggle = true;

	libusb_close(qdl_usb->usb_handle);		/* drops the claim too */
	qdl_usb->usb_handle = NULL;
	libusb_exit(NULL);

	/* Drop bytes buffered from the dead session so the fresh handle's first
	 * read returns the re-emitted HELLO, not stale pushback data. */
	qdl_clear_pending(qdl);

	usleep(USB_RESET_SETTLE_US);

	for (tries = 0; tries < USB_REOPEN_RETRIES; tries++) {
		ret = try_usb_open(qdl, serial, NULL);
		if (ret == 0)
			return 0;
		usleep(250000);
	}

	return -ENODEV;
}

struct qdl_device *usb_init(void)
{
	struct qdl_device *qdl = malloc(sizeof(struct qdl_device_usb));

	if (!qdl)
		return NULL;

	memset(qdl, 0, sizeof(struct qdl_device_usb));

	qdl->dev_type = QDL_DEVICE_USB;
	qdl->open = usb_open;
	qdl->read = usb_read;
	qdl->write = usb_write;
	qdl->close = usb_close;
	qdl->reset = usb_reset;
	qdl->set_out_chunk_size = usb_set_out_chunk_size;
	qdl->max_payload_size = 1048576;

	return qdl;
}
