// SPDX-License-Identifier: BSD-3-Clause
/*
 * Copyright (c) 2016-2017, Linaro Ltd.
 * All rights reserved.
 */
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <libxml/parser.h>
#include <libxml/tree.h>

#include "list.h"
#include "read.h"
#include "qdl.h"
#include "oscompat.h"
#include "firehose.h"
#include "gpt.h"

int read_op_load(struct list_head *ops, const char *read_op_file, const char *incdir)
{
	struct firehose_op *read_op;
	xmlNode *node;
	xmlNode *root;
	xmlDoc *doc;
	int errors;
	char tmp[PATH_MAX];

	doc = xmlReadFile(read_op_file, NULL, 0);
	if (!doc) {
		ux_err("failed to parse read-type file \"%s\"\n", read_op_file);
		return -EINVAL;
	}

	root = xmlDocGetRootElement(doc);
	for (node = root->children; node ; node = node->next) {
		if (node->type != XML_ELEMENT_NODE)
			continue;

		if (xmlStrcmp(node->name, (xmlChar *)"read")) {
			ux_err("unrecognized tag \"%s\" in read-type file \"%s\", ignoring\n",
			       node->name, read_op_file);
			continue;
		}

		errors = 0;

		read_op = firehose_alloc_op(FIREHOSE_OP_READ);

		int optional = 0;

		read_op->sector_size = attr_as_unsigned(node, "SECTOR_SIZE_IN_BYTES", &errors);
		read_op->filename = attr_as_string(node, "filename", &errors);
		read_op->partition = attr_as_unsigned(node, "physical_partition_number", &errors);
		read_op->num_sectors = attr_as_unsigned(node, "num_partition_sectors", &errors);
		read_op->start_sector = attr_as_string(node, "start_sector", &errors);
		/* OPlus firehose requires a label; absent on stock targets */
		read_op->label = attr_as_string(node, "label", &optional);

		if (errors) {
			ux_err("errors while parsing read-type file \"%s\"\n", read_op_file);
			free((void *)read_op->filename);
			free((void *)read_op->start_sector);
			free((void *)read_op->label);
			free(read_op);
			continue;
		}

		if (incdir) {
			snprintf(tmp, PATH_MAX, "%s/%s", incdir, read_op->filename);
			if (access(tmp, F_OK) != -1)
				read_op->filename = strdup(tmp);
		}

		list_append(ops, &read_op->node);
	}

	xmlFreeDoc(doc);

	return 0;
}

int read_cmd_add(struct list_head *ops, const char *address, const char *filename)
{
	struct firehose_op *read_op;
	unsigned int start_sector;
	unsigned int num_sectors;
	char *gpt_partition;
	int partition;
	char buf[20];
	int ret;

	ret = parse_storage_address(address, &partition, &start_sector, &num_sectors, &gpt_partition);
	if (ret < 0)
		return ret;

	if (num_sectors == 0 && !gpt_partition) {
		ux_err("read command without length specifier not supported\n");
		return -1;
	}

	read_op = firehose_alloc_op(FIREHOSE_OP_READ);
	if (!read_op)
		return -1;

	read_op->sector_size = 0;
	read_op->filename = strdup(filename);
	read_op->partition = partition;
	read_op->num_sectors = num_sectors;
	sprintf(buf, "%u", start_sector);
	read_op->start_sector = strdup(buf);
	read_op->gpt_partition = gpt_partition;
	/*
	 * OPlus firehose rejects label-less reads. The gpt_partition path gets a
	 * label in gpt_resolve_deferrals; raw-sector reads have no partition to
	 * borrow from, so seed one from the filename (mirrors program_cmd_add).
	 */
	if (!gpt_partition)
		read_op->label = strdup(filename);

	list_append(ops, &read_op->node);

	return 0;
}

int sha256_cmd_add(struct list_head *ops, const char *address)
{
	struct firehose_op *op;
	unsigned int start_sector;
	unsigned int num_sectors;
	char *gpt_partition;
	int partition;
	char buf[20];
	int ret;

	ret = parse_storage_address(address, &partition, &start_sector, &num_sectors, &gpt_partition);
	if (ret < 0)
		return ret;

	if (num_sectors == 0 && !gpt_partition) {
		ux_err("sha256 command without length specifier not supported\n");
		return -1;
	}

	op = firehose_alloc_op(FIREHOSE_OP_GET_SHA256_DIGEST);
	if (!op)
		return -1;

	op->sector_size = 0;
	op->partition = partition;
	op->num_sectors = num_sectors;
	sprintf(buf, "%u", start_sector);
	op->start_sector = strdup(buf);
	op->gpt_partition = gpt_partition;

	list_append(ops, &op->node);

	return 0;
}
