// SPDX-License-Identifier: BSD-3-Clause
#include <stdarg.h>
#ifdef _WIN32
#include <windows.h>
#else
#include <sys/ioctl.h>
#endif
#include <sys/time.h>
#include <unistd.h>

#include <libxml/xmlerror.h>
#include <libxml/xmlversion.h>

#include "qdl.h"

/* libxml2 2.12 const-qualified the xmlError pointer in this callback. */
#if LIBXML_VERSION >= 21200
typedef const xmlError * ux_xml_error_ptr;
#else
typedef xmlErrorPtr ux_xml_error_ptr;
#endif

#define UX_PROGRESS_REFRESH_RATE	10
#define UX_PROGRESS_SIZE_MAX		80

/*
 * 使用 Unicode 全方块字符 (U+2588) 替代 '#'
 * 注意：UTF-8 编码下每个字符占 3 字节
 */
#define PROGRESS_CHAR "█"
#define PROGRESS_CHAR_LEN 3  /* UTF-8 字节数 */

static unsigned int ux_width;
static unsigned int ux_cur_line_length;

/* Clear ux_cur_line_length characters of the progress bar from the screen */
static void ux_clear_line(void)
{
	if (!ux_cur_line_length)
		return;

	printf("%*s\r", ux_cur_line_length, "");
	fflush(stdout);
	ux_cur_line_length = 0;
}

/*
 * libxml2 emits parser diagnostics directly to stderr by default. Route them
 * through ux_err() so the file:line context is preserved while keeping output
 * consistent with the rest of the tool.
 */
static void ux_xml_error_handler(void *ctx __unused, ux_xml_error_ptr error)
{
	const char *level;

	if (!error || error->level == XML_ERR_NONE)
		return;

	switch (error->level) {
	case XML_ERR_WARNING:
		level = "warning";
		break;
	case XML_ERR_ERROR:
		level = "error";
		break;
	case XML_ERR_FATAL:
	default:
		level = "fatal";
		break;
	}

	if (error->file)
		ux_err("libxml2 %s: %s:%d: %s",
		       level, error->file, error->line, error->message);
	else
		ux_err("libxml2 %s: %s", level, error->message);
}

#ifdef _WIN32

void ux_init(void)
{
	CONSOLE_SCREEN_BUFFER_INFO csbi;
	int columns;

	HANDLE stdoutHandle = GetStdHandle(STD_OUTPUT_HANDLE);

	if (GetConsoleScreenBufferInfo(stdoutHandle, &csbi)) {
		columns = csbi.srWindow.Right - csbi.srWindow.Left + 1;
		ux_width = MIN(columns, UX_PROGRESS_SIZE_MAX);
	}

	xmlSetStructuredErrorFunc(NULL, ux_xml_error_handler);
}

#else

void ux_init(void)
{
	struct winsize w;
	int ret;

	ret = ioctl(STDOUT_FILENO, TIOCGWINSZ, &w);
	if (!ret)
		ux_width = MIN(w.ws_col, UX_PROGRESS_SIZE_MAX);

	xmlSetStructuredErrorFunc(NULL, ux_xml_error_handler);
}

#endif

void ux_err(const char *fmt, ...)
{
	va_list ap;

	ux_clear_line();

	va_start(ap, fmt);
	vfprintf(stderr, fmt, ap);
	va_end(ap);
	fflush(stderr);
}

void ux_info(const char *fmt, ...)
{
	va_list ap;

	ux_clear_line();

	va_start(ap, fmt);
	vprintf(fmt, ap);
	va_end(ap);
	fflush(stdout);
}

void ux_log(const char *fmt, ...)
{
	va_list ap;

	if (!qdl_debug)
		return;

	ux_clear_line();

	va_start(ap, fmt);
	vprintf(fmt, ap);
	va_end(ap);
	fflush(stdout);
}

void ux_debug(const char *fmt, ...)
{
	va_list ap;

	if (!qdl_debug)
		return;

	ux_clear_line();

	va_start(ap, fmt);
	vprintf(fmt, ap);
	va_end(ap);
	fflush(stdout);
}

void ux_progress(const char *fmt, unsigned int value, unsigned int max, ...)
{
	static struct timeval last_progress_update;
	unsigned long elapsed_us;
	unsigned int bar_length;
	unsigned int bars;
	unsigned int dashes;
	struct timeval now;
	char task_name[32];
	float percent;
	va_list ap;

	/* Avoid updating more than UX_PROGRESS_REFRESH_RATE per second (tty 与管道都限速，
	 * 防止重定向时百分比行刷屏) */
	if (last_progress_update.tv_sec) {
		gettimeofday(&now, NULL);
		elapsed_us = (now.tv_sec - last_progress_update.tv_sec) * 1000000 +
			     (now.tv_usec - last_progress_update.tv_usec);

		if (elapsed_us < (1000000 / UX_PROGRESS_REFRESH_RATE))
			return;
	}

	if (value > max)
		value = max;

	va_start(ap, max);
	vsnprintf(task_name, sizeof(task_name), fmt, ap);
	va_end(ap);

	percent = max ? (float)value / max : 0.0f;

	/* 终端太窄或 stdout 被重定向(管道)时无法画进度条，但仍输出可被上层解析的纯文本
	 * 百分比行，使 EdlFlash 等管道捕获方能驱动进度显示，而非完全静默。 */
	if (ux_width < 30) {
		printf("%-20.20s %1.2f%%\n", task_name, percent * 100);
		fflush(stdout);
		gettimeofday(&last_progress_update, NULL);
		return;
	}

	bar_length = ux_width - (20 + 4 + 6);
	bars = percent * bar_length;
	dashes = bar_length - bars;

	/* 
	 * 关键改动：使用 PROGRESS_CHAR ("█") 替代 '#'
	 * 由于 '█' 是 UTF-8 字符（3 字节），而 '-' 是 ASCII（1 字节），
	 * 直接用 printf("%.*s") 会导致宽度计算错位（因为 '%.*s' 按字节数计算，
	 * 但终端显示按字符宽度计算）。
	 * 
	 * 因此改为循环输出，确保正确对齐。
	 */
	printf("%-20.20s [", task_name);
	
	/* 输出进度条 - 使用 █ 字符 */
	for (unsigned int i = 0; i < bars; i++) {
		printf("%s", PROGRESS_CHAR);
	}
	for (unsigned int i = 0; i < dashes; i++) {
		printf("-");
	}
	
	printf("] %1.2f%%", percent * 100);
	
	/* 计算当前行长度用于后续清除 */
	ux_cur_line_length = 20 + 2 + bars * PROGRESS_CHAR_LEN + dashes + 2 + 7;
	
	printf("\r");
	fflush(stdout);

	gettimeofday(&last_progress_update, NULL);
}