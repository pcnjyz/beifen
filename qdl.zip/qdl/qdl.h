/* SPDX-License-Identifier: BSD-3-Clause */
#ifndef __QDL_H__
#define __QDL_H__

#ifdef _WIN32
#include <malloc.h>
#else
#include <alloca.h>
#endif

#include <stdbool.h>
#include <stdint.h>

#include "patch.h"
#include "program.h"
#include "read.h"
#include <libxml/tree.h>
#include "vip.h"

#define container_of(ptr, typecast, member) ({                  \
	void *_ptr = (void *)(ptr);		                \
	((typeof(typecast) *)(_ptr - offsetof(typecast, member))); })

#define MIN(x, y) ({		\
	__typeof__(x) _x = (x);	\
	__typeof__(y) _y = (y);	\
	_x < _y ? _x : _y;	\
})

#define ROUND_UP(x, a) ({		\
	__typeof__(x) _x = (x);		\
	__typeof__(a) _a = (a);		\
	(_x + _a - 1) & ~(_a - 1);	\
})

#define __unused __attribute__((__unused__))

#define ARRAY_SIZE(x) (sizeof(x) / sizeof((x)[0]))
#define ALIGN_UP(p, size) ({						\
		__typeof__(size) _mask = (size) - 1;			\
		(__typeof__(p))(((uintptr_t)(p) + _mask) & ~_mask);	\
})

#define MAPPING_SZ 128

#define SAHARA_ID_EHOSTDL_IMG	13

enum QDL_DEVICE_TYPE {
	QDL_DEVICE_USB,
	QDL_DEVICE_SIM,
	QDL_DEVICE_QUD,
	/*
	 * Meta-backend: defers transport selection to the wait loop inside
	 * auto_open(), which polls libusb and (on Windows) the QUD SetupAPI
	 * enumeration each tick and binds whichever first reaches an EDL
	 * device. Resolves the UX hazard of an upfront probe timeout where
	 * the user plugs in the cable just after the grace window expires.
	 */
	QDL_DEVICE_AUTO,
};

enum qdl_storage_type {
	QDL_STORAGE_UNKNOWN,
	QDL_STORAGE_EMMC,
	QDL_STORAGE_NAND,
	QDL_STORAGE_UFS,
	QDL_STORAGE_NVME,
	QDL_STORAGE_SPINOR,
};

enum qdl_skipblock_mode {
	QDL_SKIPBLOCK_NONE,
	QDL_SKIPBLOCK_SHA256,
};

enum qdl_opt_extended {
	OPT_SIGNEDDIGESTS = 0x104,
	OPT_NO_SAHARA = 0x105,
};

struct oplus_vip_config {
	char *digest_path;
	char *sign_path;
	char *transfer_xml;
	char *verify_xml;
	char *sha256init_xml;
	char *configure_xml;
	char *partition_xml;
	int skip_transfer;
	int enabled;
};

/*
 * Dynamic OnePlus token auth (oplus_token.c). version mirrors oneplus.py's
 * deviceconfig: 1/2 use the setprojmodel path, 3 uses setprocstart +
 * setswprojmodel. For version 2/3 the model-verify name is @cm, for version 1
 * it is @projid. @program_pk / @program_token are the pk/token pair attached
 * to every program, erase and patch command once authenticated.
 */
enum oplus_auth_mode {
	OPLUS_AUTH_OFF = 0,	/* EDL_OP_AUTH unset/other: never authenticate */
	OPLUS_AUTH_FORCE,	/* EDL_OP_AUTH=1: builtin OnePlus / manual override */
	OPLUS_AUTH_AUTO,	/* EDL_OP_AUTH=auto: decide by device param projid */
};

struct oplus_token_config {
	enum oplus_auth_mode auth_mode;
	int enabled;		/* runtime: confirmed-OnePlus, run the handshake */
	int authenticated;
	int version;
	int do_demacia;
	int serial_explicit;	/* EDL_OP_SERIAL was set by the caller; never override it */
	char projid[8];
	char cm[16];
	char serial[24];
	char cf[8];
	char ato_build[8];
	char flash_mode[8];
	uint64_t device_timestamp;
	char program_pk[17];
	char program_token[1025];
};

struct qdl_device {
	enum QDL_DEVICE_TYPE dev_type;
	int fd;
	size_t max_payload_size;
	size_t sector_size;
	enum qdl_storage_type current_storage_type;
	enum qdl_skipblock_mode skipblock_mode;
	unsigned int slot;
	char serial[64];	/* device serial reported by the transport, empty if none */

	int (*open)(struct qdl_device *qdl, const char *serial);
	int (*read)(struct qdl_device *qdl, void *buf, size_t len, unsigned int timeout);
	int (*write)(struct qdl_device *qdl, const void *buf, size_t nbytes, unsigned int timeout);
	void (*close)(struct qdl_device *qdl);
	/* Optional USB port reset (software replug); NULL on transports that can't. */
	int (*reset)(struct qdl_device *qdl);
	void (*set_out_chunk_size)(struct qdl_device *qdl, long size);
	void (*set_vip_transfer)(struct qdl_device *qdl, const char *signed_table,
				 const char *chained_table);

	struct vip_transfer_data vip_data;

	struct oplus_vip_config oplus_vip;
	struct oplus_token_config oplus_token;
	int auto_reset;
	int oplus_mode;		/* programmer requires a label on read/program/erase */

	/*
	 * Pushback buffer for stream-oriented transports (Windows COM via the
	 * QDLoader driver, virtio-console, ...). When a single read crosses a
	 * Firehose message boundary - typically because the binary payload of
	 * a rawmode response trails the XML envelope in the same read - the
	 * leftover bytes are stashed here and qdl_read() returns them before
	 * pulling more data from the transport.
	 */
	char *pending_buf;
	size_t pending_len;
	size_t pending_off;
};

struct sahara_image {
	char *name;
	void *ptr;
	size_t len;
};

struct qdl_zip;

struct libusb_device_handle;

struct qdl_device *qdl_init(enum QDL_DEVICE_TYPE type);
void qdl_deinit(struct qdl_device *qdl);
int qdl_open(struct qdl_device *qdl, const char *serial);
void qdl_close(struct qdl_device *qdl);
int qdl_read(struct qdl_device *qdl, void *buf, size_t len, unsigned int timeout);
int qdl_push_back(struct qdl_device *qdl, const void *buf, size_t len);
void qdl_clear_pending(struct qdl_device *qdl);
int qdl_write(struct qdl_device *qdl, const void *buf, size_t len, unsigned int timeout);
int qdl_reset(struct qdl_device *qdl);
void qdl_set_out_chunk_size(struct qdl_device *qdl, long size);
int qdl_vip_transfer_enable(struct qdl_device *qdl, const char *vip_table_path);

struct qdl_device *usb_init(void);
struct qdl_device *sim_init(void);
struct qdl_device *qud_init(void);
struct qdl_device *auto_init(void);

/*
 * try_usb_open() - single libusb scan-and-open pass; shared between
 * the --backend usb wait loop in usb.c and the unified auto_open() loop.
 * Returns 0 on success (and emits the "Flashing/Collecting device" UX
 * line), -ENODEV when no EDL device is visible, -EBUSY when one is
 * visible but cannot be opened (typically: the Qualcomm QDLoader 9008
 * driver has claimed it), -EIO on a libusb failure. @visible_out, if
 * non-NULL, receives the count of EDL devices seen on this pass.
 *
 * qud_probe_present() returns the number of Qualcomm COM ports the QUD
 * backend enumerated via SetupAPI; 0 on non-Windows hosts.
 */
int try_usb_open(struct qdl_device *qdl, const char *serial, int *visible_out);
int qud_probe_present(void);

struct qdl_device_desc {
	int vid;
	int pid;
	char serial[16];
};

struct qdl_device_desc *usb_list(unsigned int *devices_found);

/*
 * QUD-side counterpart to qdl_device_desc. Serial here is the iSerial as
 * Windows stored it in the device-instance ID (no fixed length guarantee
 * across OEMs), and path is the kernel-driver-exposed handle the QUD
 * backend will open (e.g. "\\\\.\\COM5").
 */
struct qud_device_desc {
	unsigned int pid;
	char serial[64];
	char path[64];
};

struct qud_device_desc *qud_list(unsigned int *devices_found);

int firehose_run(struct qdl_device *qdl, struct list_head *ops);
int firehose_provision(struct qdl_device *qdl, bool skip_reset);
int firehose_read_buf(struct qdl_device *qdl, struct firehose_op *read_op, void *out_buf, size_t out_size);
int sahara_run(struct qdl_device *qdl, const struct sahara_image *images,
	       const char *ramdump_path,
	       const char *ramdump_filter);
int load_sahara_image(struct qdl_zip *zip, const char *filename, struct sahara_image *image);
void sahara_images_free(struct sahara_image *images, size_t count);
void print_hex_dump(const char *prefix, const void *buf, size_t len);
unsigned int attr_as_unsigned(xmlNode *node, const char *attr, int *errors);
const char *attr_as_string(xmlNode *node, const char *attr, int *errors);
bool attr_as_bool(xmlNode *node, const char *attr, int *errors);

void ux_init(void);
void ux_err(const char *fmt, ...);
void ux_info(const char *fmt, ...);
void ux_log(const char *fmt, ...);
void ux_debug(const char *fmt, ...);
void ux_progress(const char *fmt, unsigned int value, unsigned int size, ...);

void print_version(void);

int parse_storage_address(const char *address, int *physical_partition,
			  unsigned int *start_sector, unsigned int *num_sectors,
			  char **gpt_partition);

enum qdl_storage_type decode_storage_type(const char *storage);
const char *encode_storage_type(enum qdl_storage_type storage);
int decode_sahara_config(struct sahara_image *blob, struct sahara_image *images,
			 struct contents_filter *contents_filter);

int oplus_vip_auth(struct qdl_device *qdl);
int oplus_vip_load_env(struct oplus_vip_config *cfg);

extern bool qdl_debug;

#endif
