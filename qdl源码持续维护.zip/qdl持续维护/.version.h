#define VERSION "android-lscm-20260710"
